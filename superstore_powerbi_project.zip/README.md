# Superstore Power BI Project

## Files included
- Superstore.csv → dataset for Power BI
- DAX.txt → ready-made measures
- instructions.txt → how to build dashboard

## Dashboard Idea
- KPI Cards: Sales, Profit, Orders, Profit Margin
- Charts:
  - Sales by Category
  - Sales by Region
  - Profit by Sub-Category
  - Sales Trend
  - Segment Analysis
